package com.ufc.br.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ufc.br.model.Prato;

public interface PratoRepository extends JpaRepository<Prato, Long> {
	List<Prato> findByStatus(int status);
}
