package com.ufc.br.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ufc.br.model.Prato;
import com.ufc.br.repository.PratoRepository;
import com.ufc.br.util.ImageSaver;

@Service
public class PratoService {
	@Autowired
	private PratoRepository pratoRepository;
	
	public void add(Prato prato, MultipartFile imagem) {
		prato.setStatus(1);
		String path = "images/" + prato.getNome() + ".png";
		ImageSaver.salvarImagem(path, imagem);
		pratoRepository.save(prato);
	}
	
	public List<Prato> listarPratos() {
		return pratoRepository.findAll();
	}
	
	public Prato findById(Long id) {
		return pratoRepository.getOne(id);
	}
	
	public void remove(Long id) {
		Prato prato = pratoRepository.getOne(id);
		
		String path = "images/" + prato.getNome() + ".png";
		ImageSaver.delete(path);
		
		prato.setStatus(0);
		pratoRepository.deleteById(id);
	}
	
    public List<Prato> findStatusActive() {
        return pratoRepository.findByStatus(1);
    }
}
