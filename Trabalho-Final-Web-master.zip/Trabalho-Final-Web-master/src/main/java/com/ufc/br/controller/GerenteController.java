package com.ufc.br.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ufc.br.model.Prato;
import com.ufc.br.service.PedidoService;
import com.ufc.br.service.PratoService;

@RequestMapping("/gerente")
@Controller
public class GerenteController {
	@Autowired
	private PratoService pratoService;
	
	@Autowired
	private PedidoService pedidoService;
	
	@RequestMapping(value = "/addPrato", method = RequestMethod.GET)
	public ModelAndView addPrato(Prato prato) {
		return new ModelAndView("gerente/cadastrarPrato");
	}
	
    @RequestMapping(value = "/addPrato", method = RequestMethod.POST)
    public ModelAndView salvarPrato(@Validated Prato prato, BindingResult result, RedirectAttributes attributes, @RequestParam(value = "imagem") MultipartFile imagem) {

        ModelAndView mv = new ModelAndView("redirect:/gerente/addPrato");

        if (result.hasErrors()) {
            return addPrato(prato);
        }

        pratoService.add(prato, imagem);
        attributes.addFlashAttribute("mensagem", "Prato adicionado com sucesso!");

        return mv;
    }
    
    @RequestMapping(value = "/listarPratos", method = RequestMethod.GET)
    public ModelAndView listarPratos() {

        ModelAndView mv = new ModelAndView("gerente/listarPrato");

        mv.addObject("pratos", pratoService.findStatusActive());

        return mv;
    }
    
    @RequestMapping(value = "/editPrato/{id}", method = RequestMethod.GET)
    public ModelAndView editarPrato(@PathVariable("id") Long id) {

        ModelAndView mv = new ModelAndView("gerente/cadastrarPrato");

        Prato prato = pratoService.findById(id);
        mv.addObject(prato);

        return mv;
    }
    
    @RequestMapping(value = "/editPrato/{id}", method = RequestMethod.POST)
    public ModelAndView atualizarPrato(@PathVariable("id") Long id, @Validated Prato prato, BindingResult result,
    		RedirectAttributes attributes, @RequestParam(value = "imagem") MultipartFile imagem) {
        if (result.hasErrors()) {
            return addPrato(prato);
        }

        pratoService.add(prato, imagem);

        ModelAndView mv = new ModelAndView("redirect:/gerente/listarPratos");

        return mv;
    }

    @RequestMapping(value = "/excluirPrato/{id}", method = RequestMethod.GET)
    public String excluirPrato(@PathVariable("id") Long id) {

        pratoService.remove(id);

        return "redirect:/gerente/listarPratos";
    }
}
