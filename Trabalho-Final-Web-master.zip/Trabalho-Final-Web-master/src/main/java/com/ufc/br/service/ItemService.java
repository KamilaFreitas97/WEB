package com.ufc.br.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufc.br.model.Item;
import com.ufc.br.model.Pedido;
import com.ufc.br.repository.ItemRepository;

@Service
public class ItemService {
	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private PratoService pratoService;
	
	public void saveItens(Iterable<Item> itens) {
		itemRepository.saveAll(itens);
	}
	
	public List<Item> findByPedido(Pedido pedido) {
		return itemRepository.findByPedido(pedido);
	}
}
