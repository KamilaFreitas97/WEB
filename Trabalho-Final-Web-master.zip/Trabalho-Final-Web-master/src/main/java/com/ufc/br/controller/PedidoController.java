package com.ufc.br.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ufc.br.model.Cliente;
import com.ufc.br.model.Item;
import com.ufc.br.model.Pedido;
import com.ufc.br.service.ClienteService;
import com.ufc.br.service.ItemService;
import com.ufc.br.service.PedidoService;

import java.util.List;

@Controller
@RequestMapping("/pedido")
public class PedidoController {
	@Autowired
	private PedidoService pedidoService;
	
	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private ItemService itemService;
	
    @RequestMapping(value = "/finalizar", method = RequestMethod.GET)
    public ModelAndView finalizar(HttpSession session) {

        ModelAndView mv = new ModelAndView("redirect:/cliente/pedidosCliente");

        Object auth = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserDetails user = (UserDetails) auth;

        Cliente cliente = clienteService.findByEmail(user.getUsername());

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);

        pedido.setTotal(Double.valueOf(0));
        pedidoService.savePedido(pedido);

        Iterable<Item> carrinho = (Iterable<Item>) session.getAttribute("carrinho");

        for (Item item : carrinho) {
            item.setPedido(pedido);
        }

        itemService.saveItens(carrinho);

        Double total = (Double) session.getAttribute("total");

        pedido.setTotal(Double.valueOf(total));

        pedidoService.savePedido(pedido);

        session.removeAttribute("carrinho");
        session.removeAttribute("total");

        return mv;
    }
}
