package com.ufc.br.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ufc.br.model.Cliente;
import com.ufc.br.model.Item;
import com.ufc.br.model.Pedido;
import com.ufc.br.service.ClienteService;
import com.ufc.br.service.ItemService;
import com.ufc.br.service.PedidoService;

@RequestMapping("/cliente")
@Controller
public class ClienteController {
	
	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private PedidoService pedidoService;
	
	@Autowired
	private ItemService itemService;
	
    @RequestMapping(value = "/cadastro", method = RequestMethod.GET)
    public ModelAndView novoCliente(Cliente cliente) {
        ModelAndView mv = new ModelAndView("cliente/cadastrarCliente");
        return mv;
    }

    @RequestMapping(value = "/cadastro", method = RequestMethod.POST)
    public ModelAndView salvarCliente(@Validated Cliente cliente, BindingResult result, RedirectAttributes attributes) {

        if (result.hasErrors()) {
            return novoCliente(cliente);
        }

        clienteService.save(cliente);

        ModelAndView mv = new ModelAndView("redirect:/logar");
        return mv;
    }

    @RequestMapping(value = "/dadosCliente", method = RequestMethod.GET)
    public ModelAndView dadosCliente() {

        ModelAndView mv = new ModelAndView("cliente/dadosCliente");

        Object auth = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserDetails user = (UserDetails) auth;

        Cliente clienteDados = clienteService.findByEmail(user.getUsername());

        mv.addObject("cliente", clienteService.findById(clienteDados.getId()));

        return mv;
    }

    @RequestMapping(value = "/editarDados", method = RequestMethod.GET)
    public ModelAndView editarDadosCliente(Cliente cliente) {

        ModelAndView mv = new ModelAndView("cliente/editarDadosCliente");

        Object auth = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserDetails user = (UserDetails) auth;

        Cliente clienteDados = clienteService.findByEmail(user.getUsername());

        mv.addObject("cliente", clienteService.findById(clienteDados.getId()));

        return mv;
    }

    @RequestMapping(value = "/editarDados", method = RequestMethod.POST)
    public ModelAndView AtualizarDadosCliente(@Validated Cliente cliente, BindingResult result, RedirectAttributes attributes) {

        if (result.hasErrors()) {
            return editarDadosCliente(cliente);
        }

        clienteService.save(cliente);
        attributes.addFlashAttribute("mensagem", "Dados atualizados com sucesso.");
        ModelAndView mv = new ModelAndView("redirect:/cliente/dadosCliente");
        return mv;
    }

    @RequestMapping(value = "/pedidosCliente", method = RequestMethod.GET)
    public ModelAndView listarPedidosDoCliente() {

        ModelAndView mv = new ModelAndView("cliente/listarPedidos");

        Object auth = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserDetails user = (UserDetails) auth;

        Cliente cliente = clienteService.findByEmail(user.getUsername());

        List<Pedido> pedidosCliente = pedidoService.findByCliente(cliente);

        for (Pedido p : pedidosCliente) {

            List<Item> itens = new ArrayList<>();

            itens = itemService.findByPedido(p);
            p.setItens(itens);

        }

        if (pedidosCliente.size() == 0) {
            mv.addObject("pedidosCliente", null);
        } else {
            mv.addObject("pedidosCliente", pedidosCliente);
        }

        return mv;
    }
    
    @RequestMapping(value = "/excluirCliente/{id}", method = RequestMethod.GET)
    public String apagarConta(@PathVariable("id") Long id) {
    	clienteService.removerCliente(id);
    	return "redirect:/";
    }
}
